import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom'; // For navigation to detailed recipe pages
import './Recipe.css'; // Add styles here

import Top from '../Top.png'; // Logo image
import '../App.css'; // Shared styles

import c1 from '../c1.webp';
import c2 from '../c2.webp';
import c3 from '../c3.webp';
import c4 from '../c4.webp';

const initialCardData = [
  {
    title: 'Fresh Pepper Kung Pao Chicken',
    subtitle: 'Article',
    image: c1,
    ingredients: 'Chicken, Peppers, Soy Sauce',
    steps: '1. Prepare ingredients; 2. Stir fry chicken; 3. Add sauce and peppers.',
  },
  {
    title: 'Biang Biang Noodles',
    subtitle: 'Article',
    image: c2,
    ingredients: 'Flour, Oil, Spices',
    steps: '1. Knead dough; 2. Boil noodles; 3. Add spices and oil.',
  },
  {
    title: 'Kong-Bul (Soybean Sprouts and Bulgogi)',
    subtitle: 'Article',
    image: c3,
    ingredients: 'Soybean Sprouts, Bulgogi Meat, Sauce',
    steps: '1. Cook meat; 2. Add sprouts; 3. Simmer in sauce.',
  },
  {
    title: 'Shrimp Dumplings',
    subtitle: 'Article',
    image: c4,
    ingredients: 'Shrimp, Dumpling Wrappers, Seasoning',
    steps: '1. Mix filling; 2. Wrap dumplings; 3. Steam or fry.',
    link: '/shrimp-dumplings', // Link to detailed recipe page
  },
];

const Recipe = () => {
  const [cardData, setCardData] = useState(initialCardData);
  const [newRecipe, setNewRecipe] = useState({
    title: '',
    subtitle: 'Article',
    image: '',
    ingredients: '',
    steps: '',
  });
  const [isEditing, setIsEditing] = useState(false);
  const [editIndex, setEditIndex] = useState(null);

  const navigate = useNavigate(); // Hook to navigate between pages

  // Handle form input change
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setNewRecipe({ ...newRecipe, [name]: value });
  };

  // Handle image upload
  const handleImageUpload = (e) => {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        setNewRecipe({ ...newRecipe, image: event.target.result });
      };
      reader.readAsDataURL(file);
    }
  };

  // Add or update a recipe card
  const saveRecipe = (e) => {
    e.preventDefault();
    if (newRecipe.title && newRecipe.image && newRecipe.ingredients && newRecipe.steps) {
      if (isEditing) {
        // Update the existing card
        const updatedCards = [...cardData];
        updatedCards[editIndex] = newRecipe;
        setCardData(updatedCards);
        setIsEditing(false);
        setEditIndex(null);
      } else {
        // Add a new card
        setCardData([...cardData, newRecipe]);
      }
      setNewRecipe({ title: '', subtitle: 'Article', image: '', ingredients: '', steps: '' }); // Reset form
    } else {
      alert('Please fill in all fields and upload an image!');
    }
  };

  // Edit a recipe card
  const editRecipe = (index) => {
    setNewRecipe(cardData[index]);
    setIsEditing(true);
    setEditIndex(index);
  };

  return (
    <>
      <div className="logo-container">
        <img src={Top} alt="Top Logo" />
      </div>
      <motion.div
        initial={{ opacity: 0, x: -100 }}
        animate={{ opacity: 1, x: 0 }}
        exit={{ opacity: 0, x: 100 }}
        transition={{ duration: 0.5, ease: 'easeInOut' }}
      >
        <div className="recipe-page">
          <h1>Recipe Collection</h1>
          <p>Explore our collection of delicious recipes!</p>
        </div>

        {/* Input Form Section */}
        <div className="input-container">
          <h2>{isEditing ? 'Edit Recipe' : 'Add Your Recipe'}</h2>
          <form className="recipe-form" onSubmit={saveRecipe}>
            <input
              type="text"
              name="title"
              placeholder="Recipe Title"
              value={newRecipe.title}
              onChange={handleInputChange}
              required
            />
            <textarea
              name="ingredients"
              placeholder="Ingredients (comma-separated)"
              value={newRecipe.ingredients}
              onChange={handleInputChange}
              required
            />
            <textarea
              name="steps"
              placeholder="Steps (e.g., Step 1: ...; Step 2: ...)"
              value={newRecipe.steps}
              onChange={handleInputChange}
              required
            />
            <input
              type="file"
              accept="image/*"
              onChange={handleImageUpload}
              required={!isEditing}
            />
            <button type="submit">{isEditing ? 'Update Recipe' : 'Add Recipe'}</button>
          </form>
        </div>

        <div className="recipe-page">
          <h1>Saved Recipes</h1>
        </div>

        {/* Dynamic Card Section */}
        <div className="three-container-section">
          {cardData.map((card, index) => (
            <div className="card" key={index}>
              <img src={card.image} alt={card.title} className="card-image" />
              <div className="card-content">
                <p className="card-subtitle">{card.subtitle}</p>
                <h3 className="card-title">{card.title}</h3>
                <p className="card-ingredients"><strong>Ingredients:</strong> {card.ingredients}</p>
                <p className="card-steps"><strong>Steps:</strong> {card.steps}</p>
              </div>
              <button className="edit-button" onClick={() => editRecipe(index)}>Edit</button>
            </div>
          ))}
        </div>

        <div className="recipe-page">
          <p>© 2024 Recipe Library Brock University Roger Li 6998751, LP. All rights reserved.</p>
        </div>
      </motion.div>
    </>
  );
};

export default Recipe;
